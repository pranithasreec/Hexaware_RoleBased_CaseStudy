package com.hotbyte.backend;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.time.LocalDateTime;
import java.util.*;
import com.hexaware.dto.OrderDTO;
import com.hexaware.dto.PaymentDTO;
import com.hexaware.entity.Order;
import com.hexaware.entity.Payment;
import com.hexaware.enums.PaymentStatus;
import com.hexaware.exceptions.ResourceNotFoundException;
import com.hexaware.mapper.OrderMapper;
import com.hexaware.mapper.PaymentMapper;
import com.hexaware.repository.OrderRepository;
import com.hexaware.repository.PaymentRepository;
import com.hexaware.serviceImplementation.PaymentServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

class PaymentServiceImplTest {

    @InjectMocks
    private PaymentServiceImpl service;

    @Mock
    private PaymentRepository paymentRepository;

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private OrderMapper orderMapper;

    @Mock
    private PaymentMapper paymentMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    //  Test makePayment
    @Test
    void testMakePayment_Success() {
        int orderId = 1;

        PaymentDTO paymentDTO = new PaymentDTO();
        Payment payment = new Payment();
        Order order = new Order();
        order.setOrderId(orderId);

        when(paymentMapper.paymentDtoToPayment(paymentDTO)).thenReturn(payment);
        when(orderRepository.findById(orderId)).thenReturn(Optional.of(order));
        when(paymentRepository.save(any(Payment.class))).thenAnswer(i -> i.getArgument(0));
        when(paymentMapper.paymentToPaymentDto(any(Payment.class))).thenReturn(paymentDTO);
        when(orderMapper.orderToOrderDto(order)).thenReturn(new OrderDTO());

        PaymentDTO result = service.makePayment(paymentDTO, orderId);

        assertNotNull(result);
        assertEquals(PaymentStatus.SUCCESS, payment.getStatus());
        assertNotNull(payment.getPaymentDateTime());
        verify(paymentRepository).save(payment);
    }

}