package com.hexaware.enums;

public enum UserStatus {
	ACTIVE, INACTIVE, SUSPENDED;
}
