package com.hexaware.enums;

public enum UserRole {
	CUSTOMER,
	RESTAURANT,
	ADMIN
}
