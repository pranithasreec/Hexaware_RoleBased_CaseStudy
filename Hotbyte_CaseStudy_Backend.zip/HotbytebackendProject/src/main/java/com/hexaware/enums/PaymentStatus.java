package com.hexaware.enums;

public enum PaymentStatus {
	SUCCESS,
	FAILED,
	PENDING,
	COMPLETED
}
