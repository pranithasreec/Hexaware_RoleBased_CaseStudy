package com.hexaware.enums;

public enum CouponStatus {
	ACTIVE,
	INACTIVE,
	EXPIRED

}
