package com.hexaware.enums;

public enum RestaurantStatus {

	ACTIVE,
	INACTIVE
}
