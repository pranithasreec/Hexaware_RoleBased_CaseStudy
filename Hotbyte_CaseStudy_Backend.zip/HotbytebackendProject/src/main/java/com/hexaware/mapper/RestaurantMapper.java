package com.hexaware.mapper;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.dto.AddressDTO;
import com.hexaware.dto.RestaurantDTO;
import com.hexaware.dto.RestaurantPublicDTO;
import com.hexaware.dto.UserCreateDTO;
import com.hexaware.entity.Address;
import com.hexaware.entity.Restaurant;
import com.hexaware.entity.User;

import jakarta.annotation.PostConstruct;

@Component
public class RestaurantMapper {

    @Autowired
    private ModelMapper modelMapper;

    public Restaurant restaurantDtoToRestaurant(RestaurantDTO dto) {
        return modelMapper.map(dto, Restaurant.class);
    }

    public RestaurantDTO restaurantToRestaurantDto(Restaurant restaurant) {
        return modelMapper.map(restaurant, RestaurantDTO.class);
    }

    public Restaurant restaurantPublicDtoToRestaurant(RestaurantPublicDTO dto) {
        return modelMapper.map(dto, Restaurant.class);
    }

    public RestaurantPublicDTO restaurantToRestaurantPublicDto(Restaurant restaurant) {
        return modelMapper.map(restaurant, RestaurantPublicDTO.class);
    }

    @PostConstruct
    public void init() {
        modelMapper.addMappings(new PropertyMap<Restaurant, RestaurantDTO>() {
            @Override
            protected void configure() {
                map().setRestaurantId(source.getRestaurantId());
                using(ctx -> {
                    User user = ((Restaurant) ctx.getSource()).getUser();
                    return user != null ? modelMapper.map(user, UserCreateDTO.class) : null;
                }).map(source, destination.getUserdto());
                using(ctx -> {
                    Address address = ((Restaurant) ctx.getSource()).getAddress();
                    return address != null ? modelMapper.map(address, AddressDTO.class) : null;
                }).map(source, destination.getAddressdto());
            }
        });

        modelMapper.addMappings(new PropertyMap<RestaurantDTO, Restaurant>() {
            @Override
            protected void configure() {
                map().setRestaurantId(source.getRestaurantId());
                using(ctx -> {
                    UserCreateDTO userDTO = ((RestaurantDTO) ctx.getSource()).getUserdto();
                    return userDTO != null ? modelMapper.map(userDTO, User.class) : null;
                }).map(source, destination.getUser());
                using(ctx -> {
                    AddressDTO addressDTO = ((RestaurantDTO) ctx.getSource()).getAddressdto();
                    return addressDTO != null ? modelMapper.map(addressDTO, Address.class) : null;
                }).map(source, destination.getAddress());
            }
        });

        modelMapper.typeMap(AddressDTO.class, Address.class).addMappings(mapper -> {
            mapper.skip(Address::setAddressId);
        });
    }
}
