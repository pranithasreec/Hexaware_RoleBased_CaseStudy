package com.hexaware.exceptions;

@SuppressWarnings("serial")
public class UsernameNotFoundException extends Exception{

	public UsernameNotFoundException(String message) {
		super(message);
	}
	

}
