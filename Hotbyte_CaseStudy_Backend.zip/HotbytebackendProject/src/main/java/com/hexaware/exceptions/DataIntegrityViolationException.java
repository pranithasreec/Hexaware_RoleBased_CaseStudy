package com.hexaware.exceptions;

public class DataIntegrityViolationException extends Exception{

	public DataIntegrityViolationException(String message) {
		super(message);
	}

}
