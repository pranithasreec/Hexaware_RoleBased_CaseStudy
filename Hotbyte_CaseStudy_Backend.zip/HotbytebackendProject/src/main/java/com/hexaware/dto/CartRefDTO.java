package com.hexaware.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CartRefDTO {
    private int cartId;
}
