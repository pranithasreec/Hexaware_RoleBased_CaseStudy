package com.hexaware.controller;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.dto.CustomerDTO;
import com.hexaware.dto.MenuCategoryDTO;
import com.hexaware.dto.MenuDTO;
import com.hexaware.dto.OrderDTO;
import com.hexaware.dto.RestaurantDTO;
import com.hexaware.enums.OrderStatus;
import com.hexaware.service.RestaurantService;

@RestController
@RequestMapping("/api/restaurant")
@CrossOrigin("http://localhost:3000")
public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService;

    // Restaurant Management APIs
    @PostMapping("/register")
    public ResponseEntity<RestaurantDTO> registerRestaurant(@RequestBody RestaurantDTO restaurantDTO) {
        return ResponseEntity.ok(restaurantService.registerRestaurant(restaurantDTO));
    }

    @GetMapping("/{restaurantId}")
    public ResponseEntity<RestaurantDTO> getRestaurant(@PathVariable int restaurantId) {
        return ResponseEntity.ok(restaurantService.getRestaurant(restaurantId));
    }


    @PutMapping("/{restaurantId}")
    public ResponseEntity<RestaurantDTO> updateRestaurant(@PathVariable int restaurantId, @RequestBody RestaurantDTO restaurantDTO) {
        return ResponseEntity.ok(restaurantService.updateRestaurant(restaurantId, restaurantDTO));
    }
    @PutMapping("/{restaurantId}/activate")
    public ResponseEntity<RestaurantDTO> activateRestaurant(@PathVariable int restaurantId) {
        RestaurantDTO updated = restaurantService.updateRestaurantStatus(restaurantId, "ACTIVE");
        return ResponseEntity.ok(updated);
    }
    
    @PutMapping("/{restaurantId}/deactivate")
    public ResponseEntity<RestaurantDTO> deactivateRestaurant(@PathVariable int restaurantId) {
        RestaurantDTO updated = restaurantService.updateRestaurantStatus(restaurantId, "INACTIVE");
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{restaurantId}")
    public ResponseEntity<Void> deleteRestaurant(@PathVariable int restaurantId) {
        restaurantService.deleteRestaurant(restaurantId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/all")
    public ResponseEntity<List<RestaurantDTO>> getAllRestaurants() {
        return ResponseEntity.ok(restaurantService.getAllRestaurants());
    }
    
    @PutMapping("/status")
    public ResponseEntity<RestaurantDTO> toggleRestaurantStatus(Principal principal, @RequestBody Map<String, Boolean> request) {
        String username = principal.getName();
        boolean open = request.get("open"); // true = ACTIVE, false = INACTIVE
        RestaurantDTO updated = restaurantService.toggleStatusByUsername(username, open);
        return ResponseEntity.ok(updated);
    }
    
    @GetMapping("/current")
    public ResponseEntity<RestaurantDTO> getCurrentRestaurant(Principal principal) {
        String username = principal.getName();
        return ResponseEntity.ok(restaurantService.getRestaurantByUserName(username));
    }
    
    @GetMapping("/get")
    public ResponseEntity<RestaurantDTO> getRestaurantByUserName(Principal principal) {
        RestaurantDTO dto = restaurantService.getRestaurantByUserName(principal.getName());

        // Add this debug log
        System.out.println("Fetched RestaurantDTO:");
        System.out.println("Restaurant ID: " + dto.getRestaurantId());
        System.out.println("Restaurant Name: " + dto.getRestaurantName());
        System.out.println("Status: " + dto.getStatus());
        System.out.println("UserDTO: " + (dto.getUserdto() != null ? dto.getUserdto().getUsername() : "null"));
        System.out.println("AddressDTO: " + (dto.getAddressdto() != null ? dto.getAddressdto().getStreet() : "null"));

        return ResponseEntity.ok(dto);
    }




//
//    // Menu Management APIs
//    @PostMapping("/menu")
//    public ResponseEntity<MenuDTO> addMenuItem(@RequestBody MenuDTO menuDTO) {
//        return ResponseEntity.ok(restaurantService.addMenuItem(menuDTO));
//    }
//
//    @PutMapping("/menu/{id}")
//    public ResponseEntity<MenuDTO> updateMenuItem(@PathVariable int id, @RequestBody MenuDTO menuDTO) {
//        return ResponseEntity.ok(restaurantService.updateMenuItem(id, menuDTO));
//    }
//
//    @DeleteMapping("/menu/{id}")
//    public ResponseEntity<Void> deleteMenuItem(@PathVariable int id) {
//        restaurantService.deleteMenuItem(id);
//        return ResponseEntity.noContent().build();
//    }
    
 // Create a new menu category
//    @PostMapping("/category")
//    public ResponseEntity<MenuCategoryDTO> addMenuCategory(@RequestBody MenuCategoryDTO categoryDTO) {
//        return ResponseEntity.ok(restaurantService.addMenuCategory(categoryDTO));
//    }
//
//    // Get all categories
//    @GetMapping("/categories")
//    public ResponseEntity<List<MenuCategoryDTO>> getAllMenuCategories() {
//        return ResponseEntity.ok(restaurantService.getAllMenuCategories());
//    }


//    // Order Management APIs
//    @GetMapping("/orders")
//    public ResponseEntity<List<OrderDTO>> viewOrders() {
//        return ResponseEntity.ok(restaurantService.viewOrders());
//    }
//
//    @PutMapping("/orders/{id}/status")
//    public ResponseEntity<OrderDTO> updateOrderStatus(@PathVariable int id, @RequestBody OrderStatus status) {
//        return ResponseEntity.ok(restaurantService.updateOrderStatus(id, status));
//    }

//    // View All Menus
//    @GetMapping("/menus")
//    public ResponseEntity<List<MenuDTO>> viewAllMenus() {
//        return ResponseEntity.ok(restaurantService.viewAllMenus());
//    }
}