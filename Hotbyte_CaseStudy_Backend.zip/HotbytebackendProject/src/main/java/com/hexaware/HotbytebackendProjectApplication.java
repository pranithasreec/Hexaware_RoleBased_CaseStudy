package com.hexaware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotbytebackendProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotbytebackendProjectApplication.class, args);
	}

}
