// src/state/slice/dashboardSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  users: 1247,
  restaurants: 3,
  orders: 2,
  revenue: 24580,
  menuItems: 6,
  avgOrderValue: 31.98,
  commission: 2458,
  recentOrders: [
    { id: 1, name: 'Order #1', restaurant: 'Spice Garden', amount: 46.97, status: 'preparing' },
    { id: 2, name: 'Order #2', restaurant: 'Pizza Palace', amount: 16.99, status: 'delivered' },
  ],
  restaurantStatus: [
    { name: 'Spice Garden', address: '123 Main St, Downtown', rating: 4.5 },
    { name: 'Pizza Palace', address: '456 Oak Ave, Midtown', rating: 4.3 },
    { name: 'Burger Barn', address: '789 Pine Rd, Uptown', rating: 4.7 },
  ]
};

const admindashboardSlice = createSlice({
  name: 'dashboard',
  initialState,
  reducers: {}
});

export default admindashboardSlice.reducer;
