import React from 'react'; 
import { Button } from 'primereact/button';
import { PrimeIcons } from 'primereact/api';
import { useNavigate } from "react-router-dom";

export default function Buttons() {
    const nav = useNavigate();

    const SignInLogin = () => {
        nav("/login");
    };

    const SignUpUser = () => {
        nav("/signup");
    };

    return (
        <div className="card flex flex-wrap justify-content-center gap-3">
            <Button
                label="Login"
                icon={PrimeIcons.SIGN_IN}
                onClick={SignInLogin}
                style={{
                    backgroundColor: '#FFFFFF',
                    color: '#1E2A78',
                    border: '2px solid #1E2A78',
                    margin: '0.5rem',
                    fontWeight: '600'
                }}
            />
            <Button
                label="Sign Up"
                icon={PrimeIcons.USER_PLUS}
                onClick={SignUpUser}
                style={{
                    backgroundColor: '#1E2A78',
                    color: '#FFFFFF',
                    border: 'none',
                    margin: '0.5rem',
                    fontWeight: '600'
                }}
            />
        </div>
    );
}
